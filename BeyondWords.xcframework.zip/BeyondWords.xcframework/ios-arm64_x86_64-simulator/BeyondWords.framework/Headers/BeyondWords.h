//
//  BeyondWords.h
//  BeyondWords
//
//  Created by David Osorio on 22/10/2020.
//

#import <Foundation/Foundation.h>

//! Project version number for BeyondWrods.
FOUNDATION_EXPORT double BeyondWrodsVersionNumber;

//! Project version string for BeyondWrods.
FOUNDATION_EXPORT const unsigned char BeyondWrodsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeyondWrods/PublicHeader.h>


